import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Series } from 'src/app/model/series';
import { SeriesService } from 'src/app/service/series.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {

  series: Series = { id: 0, title: '', saga: '', season: 0, seasonCounter: 0, description: '', genre1: '', genre2: '', platform: '', author: '', rating: 0, state: '', fav: false, url: ''}

  constructor(
    private seriesService: SeriesService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.series = this.seriesService.getSerie(+id)
    }
  }

  saveSeries() {
    this.seriesService.saveSerie(this.series);
    this.router.navigateByUrl('/home');
  }
}
