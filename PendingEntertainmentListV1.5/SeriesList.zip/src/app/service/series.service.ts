import { Injectable } from '@angular/core';
import { Series } from '../model/series';

@Injectable({
  providedIn: 'root'
})
export class SeriesService {

  Series: Series[] = [];
  SeriesCounter: number;

  constructor() {

    this.Series = [

      {
        id: 0,
        title: 'Dark',
        url: "https://wallpapercave.com/wp/wp4056399.jpg",
        saga: 'Dark',
        season: 1,
        seasonCounter: 3,
        description: '',
        genre1: 'Mystery',
        genre2: '',
        platform: 'Netflix',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 8
      },

      {
        id: 1,
        title: 'Game of Thrones',
        url: "https://wallpapercave.com/wp/wp2730699.jpg",
        saga: 'Song of Ice and Fire',
        season: 1,
        seasonCounter: 8,
        description: '',
        genre1: 'Fantasy',
        genre2: 'Action',
        platform: 'HBO',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 6
      },

      {
        id: 2,
        title: 'The Witcher',
        url: "https://wallpapercave.com/wp/wp5261872.jpg",
        saga: 'The Witcher',
        season: 1,
        seasonCounter: 1,
        description: '',
        genre1: 'Dark Fantasy',
        genre2: 'Action',
        platform: 'Netflix',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 7
      },

      {
        id: 3,
        title: 'Black Mirror',
        url: "https://wallpapercave.com/wp/wp2096857.jpg",
        saga: 'Black Mirror',
        season: 4,
        seasonCounter: 5,
        description: '',
        genre1: 'Mystery',
        genre2: 'Sci-Fi',
        platform: 'Netflix',
        author: '',
        state: 'ON-GOING',
        chapter: 0,
        rating: 8
      },

      {
        id: 4,
        title: 'Vikings',
        url: "https://wallpapercave.com/wp/wp2647387.jpg",
        saga: 'Vikings',
        season: 1,
        seasonCounter: 6,
        description: '',
        genre1: 'Action',
        genre2: '',
        platform: 'Netflix',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 8
      },

      {
        id: 5,
        title: 'The Last Kingdom',
        url: "https://wallpapercave.com/wp/wp3844907.jpg",
        saga: 'The Last Kingdom',
        season: 1,
        seasonCounter: 3,
        description: '',
        genre1: 'Action',
        genre2: 'Medieval',
        platform: 'Netflix',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 6.5
      }
    ]
  }

  public getSeries(): Series[] {
    return this.Series;
  }

  public getSerie(id: number): Series {
    return this.Series.filter(t => t.id === id)[0];
  }

  public saveSerie(t: Series) {

    if (t.id == undefined) {
    
      t.id = this.SeriesCounter++;
      this.Series.push(t);
      
    } else {
    
      this.deleteSerie(t.id);
      this.Series.push(t);
      
      this.Series.sort((t1, t2) => t1.id < t2.id ? -1 : 1);
    }
  }

  public deleteSerie(id: number) {

    this.Series = this.Series.filter(t => t.id != id);
  }
}
