export class Series {

    id?: number;
    url: String;
    title: String;
    saga: string;
    season: number;
    seasonCounter: number;
    description: string;
    genre1: string;
    genre2?: string;
    platform: String;
    author?: String;
    state: string;

    chapter?: number;
    rating: number;
    translatedTitle?: String;
    fav?: boolean;
}
