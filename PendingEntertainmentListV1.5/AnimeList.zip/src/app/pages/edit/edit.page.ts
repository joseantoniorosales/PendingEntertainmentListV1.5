import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Anime } from 'src/app/model/anime';
import { AnimeService } from 'src/app/service/anime.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {


  anime: Anime = { id: 0, title: '', saga: '', season: 0, seasonCounter: 0, description: '', genre1: '', genre2: '', animationCompany: '', author: '', rating: 0, state: '', fav: false, url: ''}

  constructor(
    private animeService: AnimeService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.anime = this.animeService.getAnime(+id)
    }
  }

  saveAnime() {
    this.animeService.saveAnime(this.anime);
    this.router.navigateByUrl('/home');
  }

}
