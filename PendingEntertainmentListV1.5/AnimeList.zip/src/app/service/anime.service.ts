import { Injectable } from '@angular/core';
import { Anime } from '../model/anime';

@Injectable({
  providedIn: 'root'
})
export class AnimeService {

  animes: Anime[] = [];
  animeCounter: number;

  constructor() {

    this.animes = [

      {
        id: 0,
        url: "https://wallpapercave.com/wp/wp7643520.jpg",
        title: 'Tonikaku Kawaii',
        translatedTitle: 'Fly me to the Moon',
        saga: 'ToniKawa',
        season: 1,
        seasonCounter: 1,
        description: '',
        genre1: 'Slice of life',
        genre2: 'Comedy',
        animationCompany: 'Seven Arcs',
        author: '',
        state: 'ON-GOING',

        chapter: 0, rating: 9.5
      },

      {
        id: 1,
        url: "https://wallpapercave.com/wp/wp4413211.png",
        title: 'STEINS;GATE 0',
        saga: 'Science-Adventure Series (STEINS;GATE)',
        season: 2,
        seasonCounter: 2,
        description: '',
        genre1: 'Sci-Fi',
        genre2: 'Thriller',
        animationCompany: 'White Fox',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 10
      },

      {
        id: 2,
        title: 'Fate/Stay Night: Unlimited Blade Works',
        url: "https://wallpapercave.com/wp/wp3989236.jpg",
        saga: 'Fate',
        season: 2,
        seasonCounter: 2,
        description: '',
        genre1: 'Fantasy',
        genre2: 'Action',
        animationCompany: 'Ufotable',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 10
      },

      {
        id: 3,
        title: 'The God of High School',
        url: "https://wallpapercave.com/wp/wp7074073.jpg",
        saga: 'GOH',
        season: 1,
        seasonCounter: 1,
        description: '',
        genre1: 'Shonen',
        genre2: 'Action',
        animationCompany: 'MAPPA',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 7
      },

      {
        id: 4,
        title: 'Fate/Kaleid Linner Prysmma Illya 3rei',
        url: "https://wallpapercave.com/wp/wp1970861.jpg",
        saga: 'Fate (Kaleid)',
        season: 4,
        seasonCounter: 4,
        description: '',
        genre1: 'Fantasy',
        animationCompany: 'Silver Link',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 8
      },

      {
        id: 5,
        title: 'Detective Conan',
        url: "https://wallpapercave.com/wp/wp6606536.jpg",
        translatedTitle: 'Case Closed',
        saga: 'Detective Conan',
        season: 1,
        seasonCounter: 7,
        description: '',
        genre1: 'Mystery',
        animationCompany: '',
        author: '',
        state: 'ON-GOING',
        chapter: 0,
        rating: 8.5
      },

      {
        id: 6,
        title: 'Kono Subarashi Sekai ni Shukufuku Wo!',
        url: "https://wallpapercave.com/wp/wp1965848.jpg",
        translatedTitle: 'KonoSuba: God`s Blessing on this Wonderful World!',
        saga: 'KonoSuba',
        season: 1,
        seasonCounter: 2,
        description: '',
        genre1: 'Absurd Comedy',
        genre2: 'Fantasy',
        animationCompany: 'DEEN',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 9
      },

      {
        id: 7,
        title: 'Seishun Buta Yarou Bunny Girl Senpai no Yume wo Minai',
        url: "https://wallpapercave.com/wp/wp4055560.jpg",
        translatedTitle: 'Rascal Does Not Dream of Bunny Girl Senpai',
        saga: 'Bunny Girl Senpai',
        season: 1,
        seasonCounter: 1,
        description: '',
        genre1: 'Drama',
        genre2: 'Fantasy',
        animationCompany: 'CloverWorks',
        author: '',
        state: 'COMPLETED',
        chapter: 0,
        rating: 7.5
      }
    ]
  }

  public getanimes(): Anime[] {

    return this.animes;
  }

  public getAnime(id: number): Anime {

    return this.animes.filter(t => t.id === id)[0];
  }

  public saveAnime(t: Anime) {

    if (t.id == undefined) {

      t.id = this.animeCounter++;
      this.animes.push(t);

    } else {

      this.deleteAnime(t.id);
      this.animes.push(t);
      this.animes.sort((t1, t2) => t1.id < t2.id ? -1 : 1);
    }
  }

  public deleteAnime(id: number) {

    this.animes = this.animes.filter(t => t.id != id);
  }

}
