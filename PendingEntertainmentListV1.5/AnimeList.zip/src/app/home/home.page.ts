import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { Anime } from '../model/anime';
import { AnimeService } from '../service/anime.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  
  animes: Anime[] = [];

  constructor(
    private animeService: AnimeService,
    private router: Router,
    private alertController: AlertController) { }

  ngOnInit() {

    this.animes = this.animeService.getanimes();
  }

  reload() {
    this.animes = this.animeService.getanimes();
  }

  goEditAnime(id: number) {
    this.router.navigateByUrl(`/edit${id != undefined ? '/' + id : ''}`);
  }

  deleteAnime(id: number) {

    this.animeService.deleteAnime(id);
    this.animes = this.animeService.getanimes();
  }

  async presentAlertConfirm(t: Anime) {

    const alert = await this.alertController.create({

      header: 'Delete anime',
      message: `Are you sure you want to delete the anime <strong>${t.title}</strong>?`,
      buttons: [

        {
          text: 'No',
          role: 'cancel',
        },

        {
          text: 'Yes',
          handler: () => {
            this.deleteAnime(t.id);
          }
        }
      ]
    });

    await alert.present();
  }

  async presentAlertInfo(t: Anime) {

    const alert = await this.alertController.create({

      header: `Info about ${t.title}`,
      message: `
              <p>id: ${t.id}</p>
              <p>Localized Title: ${t.translatedTitle}</p>
              <p>Description: ${t.description}</p>
              <p>Saga: ${t.saga}</p>
              <p>Season: ${t.season}</p>
              <p>SeasonCounter: ${t.seasonCounter}</p>
              <p>Genre1: ${t.genre1}</p>
              <p>Genre2: ${t.genre2}</p>
              <p>Company: ${t.animationCompany}</p>
              <p>Author: ${t.author} </p>
              <p>State: ${t.state}</p>
              <p>Chapter: ${t.chapter} </p>
              <p>Rating: ${t.rating} </p>
              `
    });

    await alert.present();
  }

}
