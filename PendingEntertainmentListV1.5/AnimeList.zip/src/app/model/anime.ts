export class Anime {
    
    id: number;
    url: String;
    title: String;
    saga: string;
    season: number;
    seasonCounter: number;
    description: string;
    genre1: string;
    genre2?: string;
    animationCompany: String;
    author?: String;
    state: string;

    chapter?: number;
    rating: number;
    translatedTitle?: String;
    fav?: boolean;
}
