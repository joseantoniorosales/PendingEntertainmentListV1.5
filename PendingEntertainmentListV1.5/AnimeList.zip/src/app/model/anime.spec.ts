import { Anime } from './anime';

describe('Anime', () => {
  it('should create an instance', () => {
    expect(new Anime()).toBeTruthy();
  });
});
