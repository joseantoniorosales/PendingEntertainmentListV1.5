import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Game } from 'src/app/model/game';
import { GameService } from 'src/app/services/game.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {


  games: Game = { id: 0, title: '', saga: '', sagaEntry: 0, description: '', genre1: '', genre2: '', platforms: '', company: '', rating: 0, state: '', fav: false, url: '' }

  constructor(
    private gameService: GameService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.games = this.gameService.getGame(+id)
    }
  }

  saveGame() {
    this.gameService.saveGame(this.games);
    this.router.navigateByUrl('/home');
  }
}
