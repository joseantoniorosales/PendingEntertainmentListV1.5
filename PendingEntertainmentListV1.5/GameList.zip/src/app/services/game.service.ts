import { Injectable } from '@angular/core';
import { Game } from '../model/game';

@Injectable({
  providedIn: 'root'
})
export class GameService {

  

  games: Game[] = [];
  gameCounter: number;

  constructor() {

    this.games = [

      {
        id: 0,
        title: 'Kingdom Hearts 2.5 Final Mix',
        url: "https://wallpapercave.com/wp/6kVc1Sm.jpg",
        saga: 'Kingdom Hearts',
        sagaEntry: 2,
        description: '',
        genre1: 'Action-RPG',
        director: 'Tetsuya Nomura',
        company: 'Square Enix',
        platforms: 'PS2 Original, PS3, PS4, PS5, XBOX ONE',
        state: 'COMPLETED',
        rating: 8
      },

      {
        id: 1,
        url: "https://wallpapercave.com/wp/wp2356330.png",
        title: 'Monster Hunter World',
        saga: 'Monster Hunter',
        sagaEntry: 6,
        description: '',
        genre1: 'Monster Hunting',
        genre2: 'Action-RPG',
        company: 'CAPCOM',
        platforms: 'PS4, PS5, XBOX ONE, XBOX SERIES X, PC(STEAM)',
        state: 'ON-GOING',
        rating: 8
      },

      {
        id: 2,
        url: "https://www.nintenderos.com/wp-content/uploads/2020/09/Hades.jpg",
        title: 'Hades',
        saga: 'Hades',
        sagaEntry: 1,
        description: '',
        genre1: 'Rogue-like',
        genre2: 'Action',
        company: 'Super Giant Games',
        platforms: 'PC(STEAM, EPIC STORE), NINTENDO SWITCH',
        state: 'ON-GOING',
        rating: 8
      },

      {
        id: 3,
        url: "https://wallpapercave.com/wp/wp3742374.jpg",
        title: 'The World Ends With You',
        ogTitle: 'Subarashiki Kono Sekai De',
        saga: 'TWEWY',
        sagaEntry: 2,
        description: '',
        genre1: 'Action-RPG',
        director: 'Tetsuya Nomura',
        company: 'Square Enix',
        platforms: 'Nintendo DS (Original), Nintendo Switch (FINAL REMIX)',
        state: 'COMPLETED',
        rating: 8
      },

      {
        id: 4,
        url: "https://wallpapercave.com/wp/wp5290712.jpg",
        title: 'Persona 3 Portable',
        saga: 'Persona (Shin Megami Tensei)',
        sagaEntry: 3,
        description: '',
        genre1: 'Turn-Based RPG',
        director: '',
        company: 'ATLUS',
        platforms: 'PS2 Original, PS3',
        state: 'COMPLETED',
        rating: 8
      },

      {
        id: 5,
        url: "https://vistapointe.net/images/chaoschild-3.jpg",
        title: 'ChäoS;Child',
        saga: 'Science-Adventure Series(ChäoS)',
        sagaEntry: 2,
        description: '',
        genre1: 'Visual Novel',
        company: 'MAGES',
        platforms: 'PS4, PC(STEAM)',
        state: 'ON-GOING',
        rating: 8
      },

      {
        id: 6,
        url: "https://wallpapercave.com/wp/wp5687323.jpg",
        title: 'Fire Emblem: Awakening',
        ogTitle: 'Fire Emblem: Kakusei',
        saga: 'Fire Emblem',
        sagaEntry: 13,
        description: '',
        genre1: 'Tactics',
        genre2: 'RPG',
        company: 'Intelligent Systems',
        platforms: 'Nintendo 3DS',
        state: 'COMPLETED',
        rating: 8
      },

      {
        id: 7,
        url: "https://wallpapercave.com/wp/wp4290816.jpg",
        title: 'Devil May Cry V',
        saga: 'Devil May Cry',
        sagaEntry: 5,
        description: '',
        genre1: 'Hack & Slash',
        genre2: 'Action-Adventure',
        company: 'CAPCOM',
        platforms: 'PC(STEAM), PS4, PS5(Special Edition), XBOX ONE, XBOX SERIES X(Special Edition)',
        state: 'COMPLETED',
        rating: 8
      },

      {
        id: 8,
        url: "https://wallpapercave.com/wp/wp2099151.jpg",
        title: 'Bravely Default: Flying Fairy',
        saga: 'Bravely Default (Final Fantasy)',
        sagaEntry: 1,
        description: '',
        genre1: 'Turn-Based RPG',
        company: 'Square Enix x Team Asano',
        platforms: 'Nintendo 3DS',
        state: 'COMPLETED',
        rating: 9
      }
    ]
  }

  
  public getGames(): Game[] {
    return this.games;
  }

  public getGame(id: number): Game {
    return this.games.filter(t => t.id === id)[0];
  }

  public saveGame(t: Game) {

    if (t.id == undefined) {
    
      t.id = this.gameCounter++;
      this.games.push(t);
      
    } else {
    
      this.deleteGame(t.id);
      this.games.push(t);
      
      this.games.sort((t1, t2) => t1.id < t2.id ? -1 : 1);
    }
  }

  public deleteGame(id: number) {

    this.games = this.games.filter(t => t.id != id);
  }
}
