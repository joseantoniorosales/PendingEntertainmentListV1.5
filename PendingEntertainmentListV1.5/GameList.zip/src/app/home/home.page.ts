import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { Game } from '../model/game';
import { GameService } from '../services/game.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  
  
  games: Game[] = [];
  
  constructor(
    private gameService: GameService,
    private router: Router,
    private alertController: AlertController) { }

  ngOnInit() {

    this.games = this.gameService.getGames();
  }


  goEditGame(id: number) {
    this.router.navigateByUrl(`/edit${id != undefined ? '/' + id : ''}`);
  }

  deleteseries(id: number) {

    this.gameService.deleteGame(id);
    this.games = this.gameService.getGames();
  }

  async presentAlertConfirm(t: Game) {

    const alert = await this.alertController.create({

      header: 'Delete Game',
      message: `Are you sure you want to delete the game <strong>${t.title}</strong>?`,
      buttons: [

        {
          text: 'No',
          role: 'cancel',
        },

        {
          text: 'Yes',
          handler: () => {
            this.deleteseries(t.id);
          }
        }
      ]
    });

    await alert.present();
  }

  async presentAlertInfo(t: Game) {

    const alert = await this.alertController.create({

      header: `Info about ${t.title}`,
      message: `
              <p>id: ${t.id}</p>
              <p>Description: ${t.description}</p>
              <p>Saga: ${t.saga}</p>
              <p>SagaEntry: ${t.sagaEntry}</p>
              <p>Genre1: ${t.genre1}</p>
              <p>Genre2: ${t.genre2}</p>
              <p>Platforms: ${t.platforms}</p>
              <p>Company: ${t.company} </p>
              <p>State: ${t.state}</p>
              <p>Rating: ${t.rating} </p>
              `
    });

    await alert.present();
  }
}
