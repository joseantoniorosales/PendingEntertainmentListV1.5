export class Game {

    id: number;
    url: String;
    title: String;
    saga: String;
    sagaEntry: number;
    description: String;
    genre1: String;
    genre2?: String;
    company: String;
    platforms: String;
    state: String;
    rating: number;

    director?: String;
    hours?: number;
    levels?: number;
    ogTitle?: String;
    fav?: boolean;

}
