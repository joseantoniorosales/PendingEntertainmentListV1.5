import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { Book } from '../model/book';
import { BookService } from '../services/book.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  
  
  books: Book[] = [];
  
  constructor(
    private booksService: BookService,
    private router: Router,
    private alertController: AlertController) { }

  ngOnInit() {

    this.books = this.booksService.getBooks();
  }


  goEditbooks(id: number) {
    this.router.navigateByUrl(`/edit${id != undefined ? '/' + id : ''}`);
  }

  deletebooks(id: number) {

    this.booksService.deleteBook(id);
    this.books = this.booksService.getBooks();
  }

  async presentAlertConfirm(t: Book) {

    const alert = await this.alertController.create({

      header: 'Delete books',
      message: `Are you sure you want to delete the book <strong>${t.title}</strong>?`,
      buttons: [

        {
          text: 'No',
          role: 'cancel',
        },

        {
          text: 'Yes',
          handler: () => {
            this.deletebooks(t.id);
          }
        }
      ]
    });

    await alert.present();
  }

  async presentAlertInfo(t: Book) {

    const alert = await this.alertController.create({

      header: `Info about ${t.title}`,
      message: `
              <p>id: ${t.id}</p>
              <p>Description: ${t.description}</p>
              <p>Saga: ${t.saga}</p>
              <p>SagaEntry: ${t.sagaEntry}</p>
              <p>Genre1: ${t.genre1}</p>
              <p>Genre2: ${t.genre2}</p>
              <p>Author: ${t.author} </p>
              <p>State: ${t.state}</p>
              <p>Chapter: ${t.chapter} </p>
              <p>Rating: ${t.rating} </p>
              `
    });

    await alert.present();
  }
}

