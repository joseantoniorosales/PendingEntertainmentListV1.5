import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Book } from 'src/app/model/book';
import { BookService } from 'src/app/services/book.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {
  
  books: Book = { id: 0, title: '', saga: '', sagaEntry: 0, description: '', genre1: '', genre2: '',  author: '', rating: 0, state: '', fav: false, url: ''}

  constructor(
    private bookService: BookService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.books = this.bookService.getBook(+id)
    }
  }

  saveBook() {
    this.bookService.saveBook(this.books);
    this.router.navigateByUrl('/home');
  }
}
