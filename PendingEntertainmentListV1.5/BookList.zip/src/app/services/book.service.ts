import { Injectable } from '@angular/core';
import { Book } from '../model/book';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  
  books: Book[] = [];
  bookCounter: number;

  constructor() {

    this.books = [

      {
        id: 0,
        url: "https://wallpapercave.com/wp/wp7462045.jpg",
        title: 'The Way of Kings',
        saga: 'The Stormlight Archive',
        sagaEntry: 1,
        description: '',
        genre1: 'Epic Fantasy',
        genre2: '',
        author: 'Brandon Sanderson',
        chapter: 0,
        pages: 0,
        state: 'ON GOING'
      },

      {
        id: 1,
        url: "https://wallpapercave.com/wp/wp6905966.jpg",
        title: 'The Last Empire',
        saga: 'Mistborn',
        sagaEntry: 1,
        description: '',
        genre1: 'Epic Fantasy',
        genre2: '',
        author: 'Brandon Sanderson',
        chapter: 0,
        pages: 0,
        state: 'COMPLETED'
      },

      {
        id: 2,
        url: "https://wallpapercave.com/wp/wp6511576.jpg",
        title: 'The Last Wish',
        saga: 'The Witcher',
        sagaEntry: 1,
        description: '',
        genre1: 'Dark Fantasy',
        genre2: '',
        author: 'Andrzej Sapkowski',
        chapter: 0,
        pages: 0,
        state: 'COMPLETED'
      },

      {
        id: 3,
        url: "https://wallpapercave.com/wp/wp7462338.jpg",
        title: 'Rhythm of War',
        saga: 'The Stormlight Archive',
        sagaEntry: 4,
        description: '',
        genre1: 'Epic Fantasy',
        genre2: '',
        author: 'Brandon Sanderson',
        chapter: 0,
        pages: 0,
        state: 'STAND-BY'
      },

      {
        id: 4,
        url: "https://wallpapercave.com/wp/x2PJyLt.jpg",
        title: 'The Lord of the Rings',
        saga: 'Middle Earth',
        sagaEntry: 3,
        description: '',
        genre1: 'Epic Fantasy',
        genre2: '',
        author: 'J.R.R Tolkien',
        chapter: 0,
        pages: 0,
        state: 'COMPLETED'
      },

      {
        id: 5,
        url: "https://wallpapercave.com/wp/wp2619141.jpg",
        title: 'Harry Potter and the Deadly Hallows',
        saga: 'Harry Potter',
        sagaEntry: 7,
        description: '',
        genre1: 'Fantasy',
        genre2: '',
        author: 'J.K Rowling',
        chapter: 0,
        pages: 0,
        state: 'COMPLETED'
      }
    ]
  }

  
  public getBooks(): Book[] {
    return this.books;
  }

  public getBook(id: number): Book {
    return this.books.filter(t => t.id === id)[0];
  }

  public saveBook(t: Book) {

    if (t.id == undefined) {
    
      t.id = this.bookCounter++;
      this.books.push(t);
      
    } else {
    
      this.deleteBook(t.id);
      this.books.push(t);
      
      this.books.sort((t1, t2) => t1.id < t2.id ? -1 : 1);
    }
  }

  public deleteBook(id: number) {

    this.books = this.books.filter(t => t.id != id);
  }
}
