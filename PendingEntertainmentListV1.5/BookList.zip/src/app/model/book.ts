export class Book {

    id?: number;
    url: String;
    title: String;
    saga: String;
    sagaEntry: number;
    description: String;
    genre1: String;
    genre2?: String;
    author: String;
    state: String;
    
    chapter?: number;
    pages?: number;
    rating?: number;
    fav?: boolean;
}
