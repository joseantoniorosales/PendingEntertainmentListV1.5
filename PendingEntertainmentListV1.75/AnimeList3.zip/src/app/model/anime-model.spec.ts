import { AnimeModel } from './anime-model';

describe('AnimeModel', () => {
  it('should create an instance', () => {
    expect(new AnimeModel()).toBeTruthy();
  });
});
