import { Injectable } from '@angular/core';

import { Plugins } from '@capacitor/core';
import { AnimeModel } from '../model/anime-model';
const { Storage } = Plugins;

@Injectable({
  providedIn: 'root'
})
export class AnimeService {
  animes: AnimeModel[] = [];
  animeCounter: number = 0;

  constructor() {
    this.getAnimesFromStorage().then(
      data => this.animes = data
    );

    this.getAnimeCounterFromStorage().then(
      data => this.animeCounter = data
    );
  }

  public getAnimes(): AnimeModel[] {
    return this.animes;
  }

  public async getAnimesFromStorage(): Promise<AnimeModel[]> {
    const ret = await Storage.get({ key: 'animes' });
    return JSON.parse(ret.value) ? JSON.parse(ret.value) : [];
  }

  public async getAnimeCounterFromStorage(): Promise<number> {
    const { value } = await Storage.get({ key: 'animeCounter' });
    return value ? +value : 0;
  }

  public getAnime(id: number) {
    return { ...this.animes.filter(t => t.id === id)[0] };
  }

  public async saveAnime(t: AnimeModel) {

    if (t.id == undefined) { // tarea nueva
      t.id = this.animeCounter++;
      this.animes.push(t);
    } else { // edición de una tarea existente
      this.animes = this.animes.filter(ta => ta.id != t.id);
      this.animes.push(t);
    }

    await this.saveAnimes(this.animes);
    await this.saveAnimeCounter(this.animeCounter);
  }

  public async saveAnimes(animes: AnimeModel[]) {
    await Storage.set({
      key: 'animes',
      value: JSON.stringify(animes)
    });
  }

  public async saveAnimeCounter(tc: number) {
    await Storage.set({
      key: 'animeCounter',
      value: '' + tc
    });
  }

  public async deleteAnime(id: number) {
    this.animes = this.animes.filter(t => t.id != id);
    await this.saveAnimes(this.animes);
  }
}

