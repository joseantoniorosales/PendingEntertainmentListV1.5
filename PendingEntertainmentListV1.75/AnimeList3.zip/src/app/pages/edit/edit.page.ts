import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AnimeModel } from 'src/app/model/anime-model';
import { AnimeService } from 'src/app/services/anime.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {

  
  anime: AnimeModel = {url: '', title: '', saga: '', season: '', seasonCounter: '', description: '', genre1: '', genre2: '', animationCompany: '', author: '', state: '', languaje: '', rating: 0};
  
  constructor(
    private animeService: AnimeService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.anime = this.animeService.getAnime(+id)
    }
  }

  saveAnime() {
    this.animeService.saveAnime(this.anime);
    this.router.navigateByUrl('/');
  }
}
