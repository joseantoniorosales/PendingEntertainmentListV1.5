import { Injectable } from '@angular/core';

import { Plugins } from '@capacitor/core';
import { BookModel } from '../model/book-model';
const { Storage } = Plugins;

@Injectable({
  providedIn: 'root'
})
export class BookService {

  books: BookModel[] = [];
  bookCounter: number = 0;

  constructor() {
    this.getBooksFromStorage().then(
      data => this.books = data
    );

    this.getBookCounterFromStorage().then(
      data => this.bookCounter = data
    );
  }

  public getBooks(): BookModel[] {
    return this.books;
  }

  public async getBooksFromStorage(): Promise<BookModel[]> {
    const ret = await Storage.get({ key: 'books' });
    return JSON.parse(ret.value) ? JSON.parse(ret.value) : [];
  }

  public async getBookCounterFromStorage(): Promise<number> {
    const { value } = await Storage.get({ key: 'bookCounter' });
    return value ? +value : 0;
  }

  public getBook(id: number) {
    return { ...this.books.filter(t => t.id === id)[0] };
  }

  public async saveBook(t: BookModel) {

    if (t.id == undefined) {
      t.id = this.bookCounter++;
      this.books.push(t);
    } else {
      this.books = this.books.filter(ta => ta.id != t.id);
      this.books.push(t);
    }

    await this.saveBooks(this.books);
    await this.saveBookCounter(this.bookCounter);
  }

  public async saveBooks(books: BookModel[]) {
    await Storage.set({
      key: 'books',
      value: JSON.stringify(books)
    });
  }

  public async saveBookCounter(tc: number) {
    await Storage.set({
      key: 'bookCounter',
      value: '' + tc
    });
  }

  public async deleteBook(id: number) {
    this.books = this.books.filter(t => t.id != id);
    await this.saveBooks(this.books);
  }
}
