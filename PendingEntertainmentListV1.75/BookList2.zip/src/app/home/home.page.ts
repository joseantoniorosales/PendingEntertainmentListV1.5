import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { BookModel } from '../model/book-model';
import { BookService } from '../services/book.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  
  
  constructor(
    public bookService: BookService,
    private router: Router,
    private alertController: AlertController
  ) { }

  goEditBook(id: number) {
    this.router.navigateByUrl(`/edit${id != undefined ? '/' + id : ''}`);
  }

  deleteBook(id: number) {
    this.bookService.deleteBook(id);
  }

  async presentAlertConfirm(t: BookModel) {
    console.log('Delete');
    const alert = await this.alertController.create({
      header: `Delete ${t.title}`,
      message: `Are you sure you want to delete <strong> ${t.title}</strong>?`,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
        }, {
          text: 'Yes',
          handler: () => {
            this.deleteBook(t.id);
          }
        }
      ]
    });
  
    await alert.present();
  }

  async presentAlertInfo(t: BookModel) {

    const alert = await this.alertController.create({

      header: `Info about ${t.title}`,
      message: `
              <p>id: ${t.id}</p>
              <p>Description: ${t.description}</p>
              <p>Saga: ${t.saga}</p>
              <p>Genre1: ${t.genre1}</p>
              <p>Genre2: ${t.genre2}</p>
              <p>Author: ${t.author} </p>
              <p>State: ${t.state}</p>
              <p>Chapter: ${t.chapter} </p>
              <p>Rating: ${t.rating} </p>
              `
    });

    await alert.present();
  }

}
