import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { SeriesModel } from '../model/series-model';
import { SerieService } from '../services/serie.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  
  
  constructor(
    public seriesService: SerieService,
    private router: Router,
    private alertController: AlertController
  ) { }

  goEditSerie(id: number) {
    this.router.navigateByUrl(`/edit${id != undefined ? '/' + id : ''}`);
  }

  deleteSerie(id: number) {
    this.seriesService.deleteSerie(id);
  }

  async presentAlertConfirm(t: SeriesModel) {
    console.log('Delete');
    const alert = await this.alertController.create({
      header: `Delete ${t.title}`,
      message: `Are you sure you want to delete <strong> ${t.title}</strong>?`,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
        }, {
          text: 'Yes',
          handler: () => {
            this.deleteSerie(t.id);
          }
        }
      ]
    });
  
    await alert.present();
  }

  async presentAlertInfo(t: SeriesModel) {

    const alert = await this.alertController.create({

      header: `Info about ${t.title}`,
      message: `
              <p>id: ${t.id}</p>
              <p>Localized Title: ${t.translatedTitle}</p>
              <p>Description: ${t.description}</p>
              <p>Saga: ${t.saga}</p>
              <p>Season: ${t.season}</p>
              <p>SeasonCounter: ${t.seasonCounter}</p>
              <p>Genre1: ${t.genre1}</p>
              <p>Genre2: ${t.genre2}</p>
              <p>Company: ${t.platform}</p>
              <p>State: ${t.state}</p>
              <p>Chapter: ${t.chapter} </p>
              <p>Rating: ${t.rating} </p>
              `
    });

    await alert.present();
  }

}
