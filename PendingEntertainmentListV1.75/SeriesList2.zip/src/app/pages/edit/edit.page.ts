import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SeriesModel } from 'src/app/model/series-model';
import { SerieService } from 'src/app/services/serie.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {

  series: SeriesModel = {url: '', title: '', saga: '', season: '', seasonCounter: '', description: '', genre1: '', genre2: '', platform: '', author: '', state: '', languaje: '', rating: 0};
  
  constructor(
    private seriesService: SerieService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.series = this.seriesService.getSerie(+id)
    }
  }

  saveSerie() {
    this.seriesService.saveSerie(this.series);
    this.router.navigateByUrl('/');
  }

}
