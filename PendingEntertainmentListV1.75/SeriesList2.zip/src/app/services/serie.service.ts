import { Injectable } from '@angular/core';

import { Plugins } from '@capacitor/core';
import { SeriesModel } from '../model/series-model';
const { Storage } = Plugins;

@Injectable({
  providedIn: 'root'
})
export class SerieService {

  series: SeriesModel[] = [];
  seriesCounter: number = 0;

  constructor() {
    this.getSeriesFromStorage().then(
      data => this.series = data
    );

    this.getSeriesCounterFromStorage().then(
      data => this.seriesCounter = data
    );
  }

  public getSeries(): SeriesModel[] {
    return this.series;
  }

  public async getSeriesFromStorage(): Promise<SeriesModel[]> {
    const ret = await Storage.get({ key: 'series' });
    return JSON.parse(ret.value) ? JSON.parse(ret.value) : [];
  }

  public async getSeriesCounterFromStorage(): Promise<number> {
    const { value } = await Storage.get({ key: 'seriesCounter' });
    return value ? +value : 0;
  }

  public getSerie(id: number) {
    return { ...this.series.filter(t => t.id === id)[0] };
  }

  public async saveSerie(t: SeriesModel) {

    if (t.id == undefined) { // tarea nueva
      t.id = this.seriesCounter++;
      this.series.push(t);
    } else { // edición de una tarea existente
      this.series = this.series.filter(ta => ta.id != t.id);
      this.series.push(t);
    }

    await this.saveSeries(this.series);
    await this.saveSeriesCounter(this.seriesCounter);
  }

  public async saveSeries(series: SeriesModel[]) {
    await Storage.set({
      key: 'series',
      value: JSON.stringify(series)
    });
  }

  public async saveSeriesCounter(tc: number) {
    await Storage.set({
      key: 'seriesCounter',
      value: '' + tc
    });
  }

  public async deleteSerie(id: number) {
    this.series = this.series.filter(t => t.id != id);
    await this.saveSeries(this.series);
  }
}
