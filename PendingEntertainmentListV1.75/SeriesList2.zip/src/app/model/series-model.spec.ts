import { SeriesModel } from './series-model';

describe('SeriesModel', () => {
  it('should create an instance', () => {
    expect(new SeriesModel()).toBeTruthy();
  });
});
