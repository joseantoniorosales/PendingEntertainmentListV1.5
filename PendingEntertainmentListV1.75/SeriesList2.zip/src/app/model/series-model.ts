export class SeriesModel {

    id?: number;
    url: String;
    title: String;
    saga: string;
    season: string;
    seasonCounter: string;
    description: string;
    genre1: string;
    genre2?: string;
    platform: String;
    author?: String;
    state: string;

    languaje: string;

    chapter?: number;
    rating: number;
    translatedTitle?: String;
    fav?: boolean;
}
