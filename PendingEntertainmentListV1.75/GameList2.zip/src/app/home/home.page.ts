import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { GameModel } from '../model/game-model';
import { GameService } from '../services/game.service';



@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  
  
  constructor(
    public gameService: GameService,
    private router: Router,
    private alertController: AlertController
  ) { }

  goEditAnime(id: number) {
    this.router.navigateByUrl(`/edit${id != undefined ? '/' + id : ''}`);
  }

  deleteAnime(id: number) {
    this.gameService.deleteGame(id);
  }

  async presentAlertConfirm(t: GameModel) {
    console.log('Delete');
    const alert = await this.alertController.create({
      header: `Delete ${t.title}`,
      message: `Are you sure you want to delete <strong> ${t.title}</strong>?`,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
        }, {
          text: 'Yes',
          handler: () => {
            this.deleteAnime(t.id);
          }
        }
      ]
    });
  
    await alert.present();
  }

  async presentAlertInfo(t: GameModel) {

    const alert = await this.alertController.create({

      header: `Info about ${t.title}`,
      message: `
              <p>id: ${t.id}</p>
              <p>Localized Title: ${t.ogTitle}</p>
              <p>Description: ${t.description}</p>
              <p>Saga: ${t.saga}</p>
              <p>Season: ${t.sagaEntry}</p>
              <p>Genre1: ${t.genre1}</p>
              <p>Genre2: ${t.genre2}</p>
              <p>Company: ${t.company}</p>
              <p>Author: ${t.director} </p>
              <p>State: ${t.state}</p>
              <p>Rating: ${t.rating} </p>
              `
    });

    await alert.present();
  }

}
