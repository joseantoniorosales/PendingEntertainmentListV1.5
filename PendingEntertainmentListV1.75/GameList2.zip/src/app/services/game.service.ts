import { Injectable } from '@angular/core';
import { GameModel } from '../model/game-model';

import { Plugins } from '@capacitor/core';
const { Storage } = Plugins;

@Injectable({
  providedIn: 'root'
})
export class GameService {

  games: GameModel[] = [];
  gameCounter: number = 0;

  constructor() {
    this.getGamesFromStorage().then(
      data => this.games = data
    );

    this.getGameCounterFromStorage().then(
      data => this.gameCounter = data
    );
  }

  public getGames(): GameModel[] {
    return this.games;
  }

  public async getGamesFromStorage(): Promise<GameModel[]> {
    const ret = await Storage.get({ key: 'games' });
    return JSON.parse(ret.value) ? JSON.parse(ret.value) : [];
  }

  public async getGameCounterFromStorage(): Promise<number> {
    const { value } = await Storage.get({ key: 'gameCounter' });
    return value ? +value : 0;
  }

  public getGame(id: number) {
    return { ...this.games.filter(t => t.id === id)[0] };
  }

  public async saveGame(t: GameModel) {

    if (t.id == undefined) { // tarea nueva
      t.id = this.gameCounter++;
      this.games.push(t);
    } else { // edición de una tarea existente
      this.games = this.games.filter(ta => ta.id != t.id);
      this.games.push(t);
    }

    await this.saveGames(this.games);
    await this.saveGameCounter(this.gameCounter);
  }

  public async saveGames (games: GameModel[]) {
    await Storage.set({
      key: 'games',
      value: JSON.stringify(games)
    });
  }

  public async saveGameCounter(tc: number) {
    await Storage.set({
      key: 'gameCounter',
      value: '' + tc
    });
  }

  public async deleteGame(id: number) {
    this.games = this.games.filter(t => t.id != id);
    await this.saveGames(this.games);
  }
}
