import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { GameModel } from 'src/app/model/game-model';
import { GameService } from 'src/app/services/game.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {

  games: GameModel = {url: '', title: '', ogTitle: '', saga: '', OGSaga: '', sagaEntry: '', description: '', genre1: '', genre2: '', company: '', platforms: '', director: '', state: '', rating: 0};
  
  constructor(
    private gameService: GameService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    const id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.games = this.gameService.getGame(+id)
    }
  }

  saveGame() {
    this.gameService.saveGame(this.games);
    this.router.navigateByUrl('/');
  }
}
