import { GameModel } from './game-model';

describe('GameModel', () => {
  it('should create an instance', () => {
    expect(new GameModel()).toBeTruthy();
  });
});
