export class GameModel {

    id?: number;
    url: String;
    title: String;
    saga: String;
    OGSaga?: String;
    sagaEntry: String;
    description: String;
    genre1: String;
    genre2?: String;
    company: String;
    platforms: String;
    state: String;
    rating: number;

    director?: String;
    hours?: number;
    levels?: number;
    ogTitle?: String;
    fav?: boolean;
}
